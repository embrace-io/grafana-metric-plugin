# Changelog

## 1.0.1
Minor presentation tweaks.

## 1.0.0
Initial release.